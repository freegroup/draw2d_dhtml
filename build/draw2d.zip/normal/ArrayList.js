/* This notice must be untouched at all times.

FreeGroup Draw2D 0.9.31
The latest version is available at
${draw2d.website}

Copyright (c) 2006 Andreas Herz. All rights reserved.
Created 5. 11. 2006 by Andreas Herz (Web: http://www.freegroup.de )

LICENSE: LGPL

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License (LGPL) as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA,
or see http://www.gnu.org/copyleft/lesser.html
*/

/**
 * 
 * @version 0.9.31
 * @author Andreas Herz
 * @constructor
 */
draw2d.ArrayList=function()
{
   /* Properties */
   this.increment = 10;
   this.size = 0;
   this.data = new Array(this.increment);
};

draw2d.ArrayList.EMPTY_LIST = new draw2d.ArrayList();

draw2d.ArrayList.prototype.type="draw2d.ArrayList";


// reverse the ArrayList
draw2d.ArrayList.prototype.reverse=function()
{
   var newData = new Array(this.size);
   for (var i=0; i<this.size; i++)
   {
      newData[i] = this.data[this.size-i-1];
   }
   this.data = newData;
};

// getCapacity() -- returns the number of elements the vector can hold
draw2d.ArrayList.prototype.getCapacity=function() 
{
   return this.data.length;
};

// getSize() -- returns the current size of the vector
draw2d.ArrayList.prototype.getSize=function() 
{
   return this.size;
};

// isEmpty() -- checks to see if the Vector has any elements
draw2d.ArrayList.prototype.isEmpty=function() 
{
   return this.getSize() === 0;
};

// getLastElement() -- returns the last element
draw2d.ArrayList.prototype.getLastElement=function() 
{
   if (this.data[this.getSize() - 1] !== null) 
   {
      return this.data[this.getSize() - 1];
   }
};

//
draw2d.ArrayList.prototype.asArray=function() 
{
  this.trimToSize();
  return this.data;
};

// getFirstElement() -- returns the first element
draw2d.ArrayList.prototype.getFirstElement=function() 
{
   if (this.data[0] !== null && this.data[0] !==undefined) 
   {
      return this.data[0];
   }
   return null;
};

// getElementAt() -- returns an element at a specified index
draw2d.ArrayList.prototype.get=function(/*:int*/i)
{
   return this.data[i];
};

// add() -- adds a element at the end of the Vector
draw2d.ArrayList.prototype.add=function(obj)
{
   if(this.getSize() == this.data.length) 
   {
      this.resize();
   }
   this.data[this.size++] = obj;
};

// add() -- adds a element at the end of the Vector
draw2d.ArrayList.prototype.addAll=function(obj)
{
   for (var i=0;i<obj.getSize(); i++) 
   {
      this.add(obj.get(i));
   }
};

// indexOf() -- returns the index of a searched element
draw2d.ArrayList.prototype.remove=function(obj)
{
   var index = this.indexOf(obj);
   if(index>=0)
    return this.removeElementAt(index);
   return null;
};


// insertElementAt() -- inserts an element at a given position
draw2d.ArrayList.prototype.insertElementAt=function(obj, index) 
{
   if (this.size == this.capacity) 
   {
      this.resize();
   }
   
   for (var i=this.getSize(); i > index; i--) 
   {
      this.data[i] = this.data[i-1];
   }
   this.data[index] = obj;
   this.size++;
};

// removeElementAt() -- removes an element at a specific index
draw2d.ArrayList.prototype.removeElementAt=function(index)
{
   var element = this.data[index];

   for(var i=index; i<(this.getSize()-1); i++)
   {
      this.data[i] = this.data[i+1];
   }

   this.data[this.getSize()-1] = null;
   this.size--;
   return element;
};

// removeAllElements() -- removes all elements in the Vector
draw2d.ArrayList.prototype.removeAllElements=function()
{
   this.size = 0;

   for (var i=0; i<this.data.length; i++) 
   {
      this.data[i] = null;
   }
};

// indexOf() -- returns the index of a searched element
draw2d.ArrayList.prototype.indexOf=function(obj)
{
   for (var i=0; i<this.getSize(); i++) 
   {
      if (this.data[i] == obj) 
      {
         return i;
      }
   }
   return -1;
};

// contains() -- returns true if the element is in the Vector, otherwise false
draw2d.ArrayList.prototype.contains=function(obj) 
{
   for (var i=0; i<this.getSize(); i++) 
   {
      if (this.data[i] == obj)
      {
         return true;
      }
   }
   return false;
};

// resize() -- increases the size of the Vector
draw2d.ArrayList.prototype.resize=function()
{
   newData = new Array(this.data.length + this.increment);

   for   (var i=0; i< this.data.length; i++) 
   {
      newData[i] = this.data[i];
   }

   this.data = newData;
};


// trimToSize() -- trims the vector down to it's size
draw2d.ArrayList.prototype.trimToSize=function()
{
   // nothing to do
   if(this.data.length == this.size)
      return;

   var temp = new Array(this.getSize());

   for (var i = 0; i < this.getSize(); i++) 
   {
      temp[i] = this.data[i];
   }
   this.size = temp.length;
   this.data = temp;
} 

// sort() - sorts the collection based on a field name - f
draw2d.ArrayList.prototype.sort=function(f) 
{
   var i, j;
   var currentValue;
   var currentObj;
   var compareObj;
   var compareValue;

   for(i=1; i<this.getSize();i++) 
   {
      currentObj = this.data[i];
      currentValue = currentObj[f];

      j= i-1;
      compareObj = this.data[j];
      compareValue = compareObj[f];

      while(j >=0 && compareValue > currentValue) 
      {
         this.data[j+1] = this.data[j];
         j--;
         if (j >=0) {
                  compareObj = this.data[j];
                  compareValue = compareObj[f];
         }
      }
      this.data[j+1] = currentObj;
   }
};

// clone() -- copies the contents of a Vector to another Vector returning the new Vector.
draw2d.ArrayList.prototype.clone=function() 
{
   var newVector = new draw2d.ArrayList(this.size);

   for (var i=0; i<this.size; i++) {
      newVector.add(this.data[i]);
   }

   return newVector;
};

// overwriteElementAt() - overwrites the element with an object at the specific index.
draw2d.ArrayList.prototype.overwriteElementAt=function(obj, index) 
{
   this.data[index] = obj;
};

draw2d.ArrayList.prototype.getPersistentAttributes=function()
{
   return {
          data: this.data,
          increment: this.increment,
          size: this.getSize()
          };
};

