/**
This notice must be untouched at all times.
This is the COMPRESSED version of Draw2D
WebSite: http://www.draw2d.org
Copyright: 2006 Andreas Herz. All rights reserved.
Created: 5.11.2006 by Andreas Herz (Web: http://www.freegroup.de )
LICENSE: LGPL
**/

draw2d.PropertyChangeEvent=function(_992,_993,_994,_995){this.model=_992;this.property=_993;this.oldValue=_994;this.newValue=_995;};draw2d.PropertyChangeEvent.prototype.type="draw2d.PropertyChangeEvent";